//Laboration 4- GUI-Kalkylator
//David Nilsson L�fvall
//Dalo1300
//L�rare: Mikael Nilsson / Robert Jonsson
/*Detta �r en testklass f�r Calculator*/


import java.io.IOException;

import javax.swing.SwingUtilities;

public class CalcTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable(){
			public void run(){
			Calculator newCalc;
			newCalc= new Calculator();
		}
			
	
	});

	}
}
	
